            <?php
        include("..\..\SGBD.php");
            $modelo = trim(htmlspecialchars($_REQUEST["s_mmodelo"], ENT_QUOTES, "UTF-8"));
            $nombre = trim(htmlspecialchars($_REQUEST["s_mnombre"], ENT_QUOTES, "UTF-8"));
            $id = trim(htmlspecialchars($_REQUEST["id"], ENT_QUOTES, "UTF-8"));
            
            //CON1
            $i = SGBD::Update("sensores","Modelo = '$modelo',Nombre = '$nombre'","Id = $id");
        //HEADER QUE MANDA UN MENSAJE A inicio.php
            header('location: ..\..\m_data.php?s_mensaje=SENSOR ACTUALIZADO');
            
            ?>